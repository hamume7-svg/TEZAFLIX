# TEZAFLIX V3 – Repair + Real Supabase Foundation

ይህ version በተለይ Preview ላይ "Your app is starting..." ብቻ እንዳይቆይ ተዘጋጅቷል።

## 1. Replit Secrets
Replit → Secrets ውስጥ እነዚህን 2 አስገባ:

VITE_SUPABASE_URL = የSupabase Project URL
VITE_SUPABASE_PUBLISHABLE_KEY = Supabase Publishable key

Secret/service-role key አታስገባ።

## 2. Google Login
Supabase → Authentication → Providers → Google ላይ Google provider መክፈት አለበት።
Google OAuth Client ID/Secret እና redirect URL በSupabase መመሪያ መሰረት ይዋቀራሉ።

## 3. Database
ነባሩ TEZAFLIX_schema.sql እንዳለ ይቀጥላል። ይህ code አዲስ database አይሰራም።

## 4. ቀጣይ
- Admin dashboard
- Poster upload to Supabase Storage
- Movie/Series upload
- Search/categories
- My List
- Continue Watching
- Premium/subscription
- Secure video delivery
- Android/Play Store

ማስታወሻ፦ ቪዲዮ ፋይሎችን በSupabase free storage ብዙ መጠን መያዝ አይመከርም። በኋላ R2/CDN/HLS እንጨምራለን።
