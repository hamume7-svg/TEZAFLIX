import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { createClient } from "@supabase/supabase-js";
import { Search, Home, Film, Tv, User, LogOut, Plus, Heart, Play, ShieldCheck, AlertCircle, X } from "lucide-react";
import "./style.css";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || "";
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || "";
const supabase = SUPABASE_URL && SUPABASE_KEY ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;

const demoMovies = [
  { id:"demo-1", title:"TEZAFLIX", title_am:"የኢትዮጵያ ታሪኮች", description:"Your Ethiopian streaming home.", type:"movie", genre:"Drama", year:2026, duration_minutes:120, rating:8.5, poster_url:"", video_url:"", is_premium:false }
];

function App(){
  const [session,setSession]=useState(null);
  const [profile,setProfile]=useState(null);
  const [movies,setMovies]=useState([]);
  const [page,setPage]=useState("home");
  const [search,setSearch]=useState("");
  const [lang,setLang]=useState("am");
  const [authOpen,setAuthOpen]=useState(false);
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");

  useEffect(()=>{
    if(!supabase) return;
    supabase.auth.getSession().then(({data})=>setSession(data.session));
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_event,s)=>setSession(s));
    return ()=>subscription.unsubscribe();
  },[]);

  useEffect(()=>{
    if(!session){ setProfile(null); return; }
    loadProfile(session.user.id);
  },[session]);

  useEffect(()=>{ loadMovies(); },[]);

  async function loadProfile(uid){
    if(!supabase) return;
    const {data,error:e}=await supabase.from("profiles").select("*").eq("id",uid).maybeSingle();
    if(!e) setProfile(data);
  }

  async function loadMovies(){
    if(!supabase){ setMovies(demoMovies); return; }
    const {data,error:e}=await supabase.from("movies").select("*").order("created_at",{ascending:false});
    if(e){ setError(e.message); setMovies(demoMovies); return; }
    setMovies(data?.length ? data : []);
  }

  async function googleLogin(){
    setError("");
    if(!supabase){ setError("Supabase is not connected yet. Add the two VITE_ secrets."); return; }
    const {error:e}=await supabase.auth.signInWithOAuth({
      provider:"google",
      options:{redirectTo:window.location.origin}
    });
    if(e) setError(e.message);
  }

  async function logout(){
    if(supabase) await supabase.auth.signOut();
    setPage("home");
  }

  const filtered=useMemo(()=>{
    const q=search.trim().toLowerCase();
    if(!q) return movies;
    return movies.filter(m=>[m.title,m.title_am,m.genre,m.description,m.description_am].filter(Boolean).some(v=>v.toLowerCase().includes(q)));
  },[movies,search]);

  const text=(am,en)=>lang==="am"?am:en;

  return <div className="app">
    <header className="topbar">
      <button className="brand" onClick={()=>setPage("home")}>TEZA<span>FLIX</span></button>
      <div className="top-actions">
        <button className="icon-btn" onClick={()=>setPage("search")}><Search size={20}/></button>
        <button className="lang" onClick={()=>setLang(lang==="am"?"en":"am")}>{lang==="am"?"EN":"አማ"}</button>
        {session ? <button className="avatar-btn" onClick={()=>setPage("account")}><User size={19}/></button> : <button className="login-btn" onClick={()=>setAuthOpen(true)}>{text("ግባ","Login")}</button>}
      </div>
    </header>

    {page==="home" && <main>
      <section className="hero">
        <div>
          <p className="eyebrow">ETHIOPIAN STREAMING</p>
          <h1>{text("የኢትዮጵያ ታሪኮች፣ በአንድ ቦታ","Ethiopian stories, one home.")}</h1>
          <p className="hero-copy">{text("ፊልሞችን እና ሲሪዎችን በTEZAFLIX ይመልከቱ።","Watch Ethiopian movies and series on TEZAFLIX.")}</p>
          <button className="primary" onClick={()=>setPage("movies")}><Play size={18} fill="currentColor"/> {text("አሁን ይመልከቱ","Watch now")}</button>
        </div>
      </section>
      <section className="section">
        <div className="section-head"><h2>{text("አዳዲስ","Latest")}</h2><button onClick={()=>setPage("movies")}>See all</button></div>
        <MovieGrid items={filtered.slice(0,10)} lang={lang}/>
      </section>
    </main>}

    {page==="movies" && <main className="section page"><div className="section-head"><h2>{text("ፊልሞች","Movies")}</h2></div><MovieGrid items={filtered.filter(x=>x.type==="movie")} lang={lang}/></main>}
    {page==="series" && <main className="section page"><div className="section-head"><h2>{text("ሲሪዎች","Series")}</h2></div><MovieGrid items={filtered.filter(x=>x.type==="series")} lang={lang}/></main>}
    {page==="search" && <main className="section page"><div className="searchbox"><Search size={19}/><input autoFocus value={search} onChange={e=>setSearch(e.target.value)} placeholder={text("ፊልም፣ ሲሪ ፈልግ...","Search movies, series...")}/>{search&&<button onClick={()=>setSearch("")}><X size={18}/></button>}</div><MovieGrid items={filtered} lang={lang}/></main>}
    {page==="account" && <main className="section page"><div className="account-card"><User size={35}/><h2>{profile?.full_name || session?.user?.email || "User"}</h2><p>{session?.user?.email}</p>{profile?.role==="admin"&&<div className="admin-badge"><ShieldCheck size={16}/> ADMIN</div>}<button className="danger" onClick={logout}><LogOut size={17}/> {text("ውጣ","Logout")}</button></div></main>}

    <nav className="bottom-nav">
      <Nav active={page==="home"} icon={<Home size={20}/>} label={text("ቤት","Home")} onClick={()=>setPage("home")}/>
      <Nav active={page==="movies"} icon={<Film size={20}/>} label={text("ፊልም","Movies")} onClick={()=>setPage("movies")}/>
      <Nav active={page==="series"} icon={<Tv size={20}/>} label={text("ሲሪ","Series")} onClick={()=>setPage("series")}/>
      <Nav active={page==="search"} icon={<Search size={20}/>} label={text("ፈልግ","Search")} onClick={()=>setPage("search")}/>
      <Nav active={page==="account"} icon={<User size={20}/>} label={text("አካውንት","Account")} onClick={()=>session?setPage("account"):setAuthOpen(true)}/>
    </nav>

    {!SUPABASE_URL || !SUPABASE_KEY ? <div className="setup-warning"><AlertCircle size={17}/><span>Supabase secrets are missing. The app still loads safely; add VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY to connect the real database.</span></div>:null}
    {error && <div className="toast"><AlertCircle size={17}/>{error}<button onClick={()=>setError("")}><X size={16}/></button></div>}
    {authOpen && <AuthModal onClose={()=>setAuthOpen(false)} onGoogle={googleLogin} supabase={supabase} loading={loading} setLoading={setLoading} error={error} setError={setError}/>}
  </div>
}

function Nav({active,icon,label,onClick}){return <button className={active?"nav active":"nav"} onClick={onClick}>{icon}<span>{label}</span></button>}

function MovieGrid({items,lang}){
  if(!items.length) return <div className="empty"><Film size={35}/><p>{lang==="am"?"እስካሁን ይዘት አልተጫነም።":"No content has been added yet."}</p></div>;
  return <div className="grid">{items.map(m=><article className="card" key={m.id}><div className="poster">{m.poster_url?<img src={m.poster_url} alt=""/>:<div className="poster-fallback">TEZA<span>FLIX</span></div>}{m.is_premium&&<b className="premium">PREMIUM</b>}<button className="play"><Play size={18} fill="white"/></button></div><h3>{lang==="am"&&m.title_am?m.title_am:m.title}</h3><p>{m.genre||"Ethiopian"} • {m.year||""}</p></article>)}</div>
}

function AuthModal({onClose,onGoogle,supabase,loading,setLoading,error,setError}){
  const [mode,setMode]=useState("login");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [name,setName]=useState("");

  async function submit(e){
    e.preventDefault(); setError("");
    if(!supabase){setError("Supabase secrets are missing.");return}
    setLoading(true);
    try{
      if(mode==="login"){
        const {error:e}=await supabase.auth.signInWithPassword({email,password}); if(e) throw e;
      }else{
        const {error:e}=await supabase.auth.signUp({email,password,options:{data:{full_name:name}}}); if(e) throw e;
        setError("Registration complete. If email confirmation is enabled, confirm your email before logging in.");
      }
    }catch(e){setError(e.message)}
    finally{setLoading(false)}
  }

  return <div className="modal-backdrop"><div className="modal"><button className="close" onClick={onClose}><X/></button><h2>{mode==="login"?"Welcome back":"Create account"}</h2><p className="muted">TEZAFLIX</p>
    {mode==="register"&&<input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name"/>}
    <input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="Email"/>
    <input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password"/>
    <button className="primary full" onClick={submit} disabled={loading}>{loading?"Please wait...":mode==="login"?"Login":"Register"}</button>
    <div className="or"><span>OR</span></div>
    <button className="google" onClick={onGoogle}><b>G</b> Continue with Google</button>
    <button className="switch" onClick={()=>setMode(mode==="login"?"register":"login")}>{mode==="login"?"Create a new account":"Already have an account? Login"}</button>
    {error&&<div className="modal-error">{error}</div>}
  </div></div>
}

createRoot(document.getElementById("root")).render(<App/>);