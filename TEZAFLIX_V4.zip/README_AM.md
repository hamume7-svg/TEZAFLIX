# TEZAFLIX V4

V4 adds:
- Red/black TEZAFLIX branding
- Email/password + Google login
- Admin dashboard
- Poster upload to Supabase Storage bucket `posters`
- Video upload to Supabase Storage bucket `movies`
- Movie metadata and Free/Premium flag
- Catalog and video player
- Mobile-first layout

## Supabase
1. Keep your existing `profiles` table and admin role.
2. Create Storage buckets named exactly `movies` and `posters`.
3. Keep the Storage policies already created.
4. Run `SUPABASE_V4.sql` once.
5. GitHub Actions must provide:
   VITE_SUPABASE_URL
   VITE_SUPABASE_PUBLISHABLE_KEY

## Important
Large production video libraries should eventually use a dedicated video/CDN service and HLS rather than storing very large files directly in Supabase Storage.
Never put a Supabase `service_role`/`sb_secret_...` key in the app.
Only upload films you own or are licensed to distribute.
