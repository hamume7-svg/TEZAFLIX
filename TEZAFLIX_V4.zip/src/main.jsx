import React, {useEffect, useMemo, useState} from "react";
import {createRoot} from "react-dom/client";
import {createClient} from "@supabase/supabase-js";
import "./style.css";

const SUPABASE_URL=import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY=import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
const supabase=(SUPABASE_URL&&SUPABASE_KEY)?createClient(SUPABASE_URL,SUPABASE_KEY):null;

const demo=[
 {id:"demo1",title:"TEZAFLIX Demo",description:"ይህ የሙከራ ፊልም ነው።",genre:"Drama",year:2026,rating:8.5,is_premium:false,poster_url:"",video_url:""}
];

function App(){
 const [session,setSession]=useState(null),[profile,setProfile]=useState(null),[movies,setMovies]=useState([]),
 [view,setView]=useState("home"),[search,setSearch]=useState(""),[loading,setLoading]=useState(true),
 [error,setError]=useState(""),[authMode,setAuthMode]=useState("login"),[email,setEmail]=useState(""),
 [password,setPassword]=useState(""),[busy,setBusy]=useState(false),[selected,setSelected]=useState(null);

 useEffect(()=>{let alive=true;(async()=>{
   if(!supabase){setLoading(false);return}
   const {data}=await supabase.auth.getSession();
   if(alive){setSession(data.session); if(data.session) await loadProfile(data.session.user.id); await loadMovies(); setLoading(false);}
   const {data:sub}=supabase.auth.onAuthStateChange(async(_,s)=>{setSession(s);if(s) await loadProfile(s.user.id);else setProfile(null);});
   return ()=>{alive=false;sub.subscription.unsubscribe()}
 })()},[]);

 async function loadProfile(uid){
   const {data}=await supabase.from("profiles").select("*").eq("id",uid).maybeSingle();
   setProfile(data||null);
 }
 async function loadMovies(){
   if(!supabase){setMovies(demo);return}
   const {data,error}=await supabase.from("movies").select("*").order("created_at",{ascending:false});
   if(error){setError(error.message);setMovies(demo)}else setMovies(data||[]);
 }
 async function login(e){
   e.preventDefault(); setBusy(true);setError("");
   const {error}=await supabase.auth.signInWithPassword({email,password});
   if(error)setError(error.message); setBusy(false);
 }
 async function register(e){
   e.preventDefault();setBusy(true);setError("");
   const {error}=await supabase.auth.signUp({email,password});
   if(error)setError(error.message);else setError("Account created. Check your email if confirmation is enabled.");
   setBusy(false);
 }
 async function google(){
   setError(""); const {error}=await supabase.auth.signInWithOAuth({provider:"google",options:{redirectTo:window.location.origin+window.location.pathname}});
   if(error)setError(error.message);
 }
 async function logout(){await supabase.auth.signOut();setView("home")}
 const filtered=useMemo(()=>movies.filter(m=>(m.title||"").toLowerCase().includes(search.toLowerCase())),[movies,search]);
 const isAdmin=profile?.role==="admin";

 if(loading)return <div className="splash"><div className="logo">TEZA<span>FLIX</span></div><p>Loading...</p></div>;

 if(!session)return <Auth mode={authMode} setMode={setAuthMode} email={email} setEmail={setEmail} password={password} setPassword={setPassword} login={login} register={register} google={google} busy={busy} error={error}/>;

 return <div className="app">
  <header><button className="brand" onClick={()=>setView("home")}>TEZA<span>FLIX</span></button>
   <div className="header-actions"><button className="iconbtn" onClick={()=>setView("search")}>⌕</button><button className="avatar" onClick={()=>setView("account")}>{(session.user.email||"U")[0].toUpperCase()}</button></div>
  </header>
  {view==="home"&&<Home movies={movies} open={setSelected} go={setView}/>}
  {view==="movies"&&<Catalog title="Movies" movies={filtered} open={setSelected}/>}
  {view==="series"&&<Catalog title="Series" movies={filtered} open={setSelected}/>}
  {view==="search"&&<div className="page"><h2>Search</h2><input className="search" placeholder="Search movies..." value={search} onChange={e=>setSearch(e.target.value)}/><Catalog title="" movies={filtered} open={setSelected}/></div>}
  {view==="account"&&<Account session={session} profile={profile} isAdmin={isAdmin} logout={logout} go={setView}/>}
  {view==="admin"&&isAdmin&&<Admin movies={movies} reload={loadMovies}/>}
  <nav><button onClick={()=>setView("home")} className={view==="home"?"active":""}>⌂<small>Home</small></button><button onClick={()=>setView("movies")} className={view==="movies"?"active":""}>▶<small>Movies</small></button><button onClick={()=>setView("search")} className={view==="search"?"active":""}>⌕<small>Search</small></button><button onClick={()=>setView("account")} className={view==="account"?"active":""}>●<small>Account</small></button></nav>
  {selected&&<Player movie={selected} close={()=>setSelected(null)}/>}
 </div>
}

function Auth(p){return <div className="auth"><div className="auth-card"><div className="logo big">TEZA<span>FLIX</span></div><h2>{p.mode==="login"?"Welcome back":"Create account"}</h2><p className="muted">Ethiopian movies & series</p>
 <button className="google" onClick={p.google}>Continue with Google</button><div className="or">or</div>
 <form onSubmit={p.mode==="login"?p.login:p.register}><input type="email" placeholder="Email" value={p.email} onChange={e=>p.setEmail(e.target.value)} required/><input type="password" placeholder="Password (6+ characters)" value={p.password} onChange={e=>p.setPassword(e.target.value)} minLength="6" required/><button className="primary" disabled={p.busy}>{p.busy?"Please wait...":p.mode==="login"?"Login":"Create account"}</button></form>
 {p.error&&<div className="error">{p.error}</div>}<button className="link" onClick={()=>p.setMode(p.mode==="login"?"register":"login")}>{p.mode==="login"?"Create a new account":"I already have an account"}</button></div></div>}

function Home({movies,open,go}){return <div className="page"><section className="hero"><div><span className="pill">TEZAFLIX ORIGINAL</span><h1>Ethiopian stories.<br/><b>Made to watch.</b></h1><p>Discover movies and series in one place.</p><button className="primary" onClick={()=>go("movies")}>▶ Explore movies</button></div></section><Catalog title="Trending" movies={movies.slice(0,8)} open={open}/></div>}
function Catalog({title,movies,open}){return <section className="section"><h2>{title}</h2><div className="grid">{movies.map(m=><button className="card" key={m.id} onClick={()=>open(m)}><div className="poster">{m.poster_url?<img src={m.poster_url}/>:<div className="poster-fallback">TEZA<span>FLIX</span></div>} {m.is_premium&&<i>PREMIUM</i>}</div><strong>{m.title}</strong><small>{m.genre||"Movie"} • {m.year||""}</small></button>)}</div>{!movies.length&&<p className="muted">No movies found.</p>}</section>}
function Account({session,profile,isAdmin,logout,go}){return <div className="page"><div className="account"><div className="avatar large">{(session.user.email||"U")[0].toUpperCase()}</div><h2>{session.user.email}</h2><p className="muted">{isAdmin?"Administrator":"Viewer"}</p>{isAdmin&&<button className="primary wide" onClick={()=>go("admin")}>👑 Admin Dashboard</button>}<button className="secondary wide" onClick={logout}>Log out</button></div></div>}
function Player({movie,close}){return <div className="modal"><button className="close" onClick={close}>×</button><div className="player">{movie.video_url?<video src={movie.video_url} controls autoPlay/>:<div className="no-video"><div className="logo">TEZA<span>FLIX</span></div><p>No video has been uploaded for this title yet.</p></div>}</div><div className="player-info"><h2>{movie.title}</h2><p>{movie.description}</p></div></div>}

function Admin({movies,reload}){
 const [title,setTitle]=useState(""),[desc,setDesc]=useState(""),[genre,setGenre]=useState("Drama"),[year,setYear]=useState("2026"),[premium,setPremium]=useState(false),
 [poster,setPoster]=useState(null),[video,setVideo]=useState(null),[busy,setBusy]=useState(false),[msg,setMsg]=useState(""),[err,setErr]=useState("");
 async function upload(){
  if(!supabase)return setErr("Supabase is not configured.");
  if(!title.trim())return setErr("Title is required.");
  setBusy(true);setMsg("");setErr("");
  try{
   let posterUrl="",videoUrl="";
   const uid=(await supabase.auth.getUser()).data.user.id;
   if(poster){const path=`${uid}/${Date.now()}-${poster.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;const r=await supabase.storage.from("posters").upload(path,poster,{upsert:false});if(r.error)throw r.error;posterUrl=supabase.storage.from("posters").getPublicUrl(path).data.publicUrl;}
   if(video){const path=`${uid}/${Date.now()}-${video.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;const r=await supabase.storage.from("movies").upload(path,video,{upsert:false});if(r.error)throw r.error;videoUrl=supabase.storage.from("movies").getPublicUrl(path).data.publicUrl;}
   const r=await supabase.from("movies").insert({title,description:desc,genre,year:Number(year)||null,is_premium:premium,poster_url:posterUrl,video_url:videoUrl}).select().single();
   if(r.error)throw r.error;
   setMsg("Movie published successfully!");setTitle("");setDesc("");setPoster(null);setVideo(null);await reload();
  }catch(e){setErr(e.message||"Upload failed");}finally{setBusy(false)}
 }
 return <div className="page"><div className="admin-head"><div><span className="pill">ADMIN</span><h1>Movie Studio</h1></div></div><div className="admin-card">
 <input placeholder="Movie title *" value={title} onChange={e=>setTitle(e.target.value)}/><textarea placeholder="Description" value={desc} onChange={e=>setDesc(e.target.value)}/>
 <div className="two"><input placeholder="Genre" value={genre} onChange={e=>setGenre(e.target.value)}/><input type="number" placeholder="Year" value={year} onChange={e=>setYear(e.target.value)}/></div>
 <label className="check"><input type="checkbox" checked={premium} onChange={e=>setPremium(e.target.checked)}/> Premium movie</label>
 <label className="file">🖼️ Poster <input type="file" accept="image/*" onChange={e=>setPoster(e.target.files?.[0]||null)}/>{poster&&<small>{poster.name}</small>}</label>
 <label className="file">🎥 Video <input type="file" accept="video/*" onChange={e=>setVideo(e.target.files?.[0]||null)}/>{video&&<small>{video.name}</small>}</label>
 <button className="primary wide" onClick={upload} disabled={busy}>{busy?"Uploading...":"Publish Movie"}</button>
 {msg&&<div className="success">{msg}</div>}{err&&<div className="error">{err}</div>}</div>
 <h2>Your catalog ({movies.length})</h2><div className="admin-list">{movies.map(m=><div key={m.id}><b>{m.title}</b><span>{m.genre||"Movie"} {m.is_premium?"• Premium":""}</span></div>)}</div></div>
}

createRoot(document.getElementById("root")).render(<App/>);