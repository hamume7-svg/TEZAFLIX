# TEZAFLIX V5

V5 adds a polished red/black streaming UI and a Premium page with Chapa checkout initialization.

## 1. GitHub Pages
Keep VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY as GitHub Actions secrets. Never add a Chapa Secret Key to GitHub Pages/frontend.

## 2. Supabase database
Run `SUPABASE_V5.sql` in Supabase SQL Editor.

## 3. Chapa secure backend
The folder `supabase/functions/chapa-initiate/index.ts` is the secure server-side initializer. Deploy it as a Supabase Edge Function named `chapa-initiate`.

Set these Edge Function secrets:
- CHAPA_SECRET_KEY = your Chapa Secret Key (test key first)
- SITE_URL = https://hamume7-svg.github.io/TEZAFLIX/

Supabase automatically provides SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY to Edge Functions. Do not expose the service-role key.

## 4. Chapa webhook / verification
Before granting Premium in production, configure a Chapa webhook and verify the transaction server-side using the Chapa verify endpoint. The V5 UI intentionally does NOT mark a user premium merely because they returned from checkout.

## 5. Current plan prices
Monthly 99 ETB; 3 Months 249 ETB; Yearly 899 ETB. Change them in `src/main.jsx` and the Edge Function together if desired.
