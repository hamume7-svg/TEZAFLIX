-- Run this once in Supabase SQL Editor.
-- Requires the existing profiles table with id + role and movies table.
-- This safely adds the fields V4 needs.

alter table public.movies add column if not exists poster_url text;
alter table public.movies add column if not exists video_url text;
alter table public.movies add column if not exists genre text;
alter table public.movies add column if not exists year integer;
alter table public.movies add column if not exists is_premium boolean default false;
alter table public.movies add column if not exists description text;
alter table public.movies add column if not exists created_at timestamptz default now();

-- If your movies table has RLS, these policies allow signed-in users to read
-- published catalog data while only admins can insert/update/delete.
alter table public.movies enable row level security;

drop policy if exists "Movies readable by everyone" on public.movies;
create policy "Movies readable by everyone"
on public.movies for select
to public using (true);

drop policy if exists "Admins can insert movies" on public.movies;
create policy "Admins can insert movies"
on public.movies for insert
to authenticated
with check (exists (
  select 1 from public.profiles p
  where p.id=auth.uid() and p.role='admin'
));

drop policy if exists "Admins can update movies" on public.movies;
create policy "Admins can update movies"
on public.movies for update
to authenticated
using (exists (
  select 1 from public.profiles p
  where p.id=auth.uid() and p.role='admin'
));

drop policy if exists "Admins can delete movies" on public.movies;
create policy "Admins can delete movies"
on public.movies for delete
to authenticated
using (exists (
  select 1 from public.profiles p
  where p.id=auth.uid() and p.role='admin'
));