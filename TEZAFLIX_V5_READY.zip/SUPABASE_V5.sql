-- TEZAFLIX V5: subscriptions + payments
create table if not exists public.subscriptions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 plan_id text not null,
 status text not null default 'pending',
 tx_ref text unique not null,
 amount numeric(12,2) not null,
 currency text not null default 'ETB',
 starts_at timestamptz,
 expires_at timestamptz,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.payments (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id) on delete set null,
 subscription_id uuid references public.subscriptions(id) on delete set null,
 tx_ref text unique not null,
 amount numeric(12,2) not null,
 currency text not null default 'ETB',
 status text not null default 'pending',
 raw_response jsonb,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
alter table public.subscriptions enable row level security;
alter table public.payments enable row level security;
drop policy if exists "Users can read own subscriptions" on public.subscriptions;
create policy "Users can read own subscriptions" on public.subscriptions for select to authenticated using (user_id=auth.uid());
drop policy if exists "Users can read own payments" on public.payments;
create policy "Users can read own payments" on public.payments for select to authenticated using (user_id=auth.uid());
create index if not exists subscriptions_user_status_idx on public.subscriptions(user_id,status);
create index if not exists subscriptions_tx_ref_idx on public.subscriptions(tx_ref);
