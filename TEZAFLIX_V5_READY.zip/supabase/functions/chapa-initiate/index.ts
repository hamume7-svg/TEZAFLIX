import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
const plans:any={monthly:{amount:99,days:30},quarterly:{amount:249,days:90},yearly:{amount:899,days:365}};
serve(async(req)=>{
 if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
 try{
  const auth=req.headers.get('Authorization'); if(!auth) throw new Error('Not authenticated');
  const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const userClient=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await userClient.auth.getUser(); if(!user) throw new Error('Not authenticated');
  const {plan_id,amount}=await req.json(); const plan=plans[plan_id]; if(!plan||Number(amount)!==plan.amount) throw new Error('Invalid plan');
  const tx_ref=`TEZA-${user.id.slice(0,8)}-${Date.now()}`;
  const {data:sub,error:subErr}=await admin.from('subscriptions').insert({user_id:user.id,plan_id,status:'pending',tx_ref,amount:plan.amount,currency:'ETB'}).select().single();
  if(subErr) throw subErr;
  const chapaSecret=Deno.env.get('CHAPA_SECRET_KEY'); if(!chapaSecret) throw new Error('CHAPA_SECRET_KEY is not configured');
  const site=Deno.env.get('SITE_URL')||'https://hamume7-svg.github.io/TEZAFLIX/';
  const payload={amount:String(plan.amount),currency:'ETB',email:user.email,first_name:user.user_metadata?.full_name?.split(' ')[0]||'TEZAFLIX',last_name:user.user_metadata?.full_name?.split(' ').slice(1).join(' ')||'User',tx_ref,callback_url:`${site}?payment=callback&tx_ref=${encodeURIComponent(tx_ref)}`,return_url:`${site}?payment=return&tx_ref=${encodeURIComponent(tx_ref)}`,customization:{title:'TEZAFLIX Premium',description:`${plan_id} subscription`}};
  const r=await fetch('https://api.chapa.co/v1/transaction/initialize',{method:'POST',headers:{Authorization:`Bearer ${chapaSecret}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const data=await r.json(); if(!r.ok||data?.status==='failed') throw new Error(data?.message||'Chapa initialization failed');
  return new Response(JSON.stringify({checkout_url:data?.data?.checkout_url,tx_ref,subscription_id:sub.id}),{headers:{...cors,'Content-Type':'application/json'}});
 }catch(e){return new Response(JSON.stringify({message:e?.message||'Payment initialization failed'}),{status:400,headers:{...cors,'Content-Type':'application/json'}})}
});
