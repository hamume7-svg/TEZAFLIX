import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const plans: Record<string, { amount: number; days: number }> = {
  monthly: { amount: 99, days: 30 },
  quarterly: { amount: 249, days: 90 },
  yearly: { amount: 899, days: 365 },
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const chapaSecret = Deno.env.get("CHAPA_SECRET_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!chapaSecret || !supabaseUrl || !serviceRoleKey) throw new Error("Payment function secrets are not configured");

    const authorization = req.headers.get("Authorization");
    if (!authorization) throw new Error("Not authenticated");

    const userClient = createClient(
      supabaseUrl,
      Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("SUPABASE_PUBLISHABLE_KEY") || "",
      { global: { headers: { Authorization: authorization } } },
    );
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) throw new Error("Not authenticated");

    const admin = createClient(supabaseUrl, serviceRoleKey);
    const body = await req.json().catch(() => ({}));
    const txRef = body?.tx_ref || body?.reference || body?.data?.tx_ref;

    if (txRef && (body?.status || body?.event || body?.data)) {
      const verify = await fetch(`https://api.chapa.co/v1/transaction/verify/${encodeURIComponent(txRef)}`, {
        headers: { Authorization: `Bearer ${chapaSecret}` },
      });
      const verified = await verify.json();
      const payment = verified?.data;
      if (verified?.status === "success" && payment?.status === "success") {
        const { data: sub } = await admin.from("subscriptions").select("*").eq("tx_ref", txRef).maybeSingle();
        if (sub && Number(payment.amount) === Number(sub.amount) && payment.currency === sub.currency) {
          const days = plans[sub.plan_id]?.days || 30;
          const starts = new Date();
          const expires = new Date(starts.getTime() + days * 86400000);
          await admin.from("subscriptions").update({ status: "active", starts_at: starts.toISOString(), expires_at: expires.toISOString(), updated_at: starts.toISOString() }).eq("id", sub.id);
          await admin.from("payments").upsert({ user_id: sub.user_id, subscription_id: sub.id, tx_ref: txRef, amount: sub.amount, currency: sub.currency, status: "success", raw_response: verified, updated_at: starts.toISOString() }, { onConflict: "tx_ref" });
        }
      }
      return new Response(JSON.stringify({ received: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { plan_id, amount } = body;
    const plan = plans[plan_id];
    if (!plan || Number(amount) !== plan.amount) throw new Error("Invalid plan");

    const tx_ref = `TEZA-${user.id.slice(0, 8)}-${Date.now()}`;
    const { data: sub, error: subError } = await admin.from("subscriptions").insert({ user_id: user.id, plan_id, status: "pending", tx_ref, amount: plan.amount, currency: "ETB" }).select("id").single();
    if (subError) throw subError;

    const siteUrl = "https://hamume7-svg.github.io/TEZAFLIX/";
    const response = await fetch("https://api.chapa.co/v1/transaction/initialize", {
      method: "POST",
      headers: { Authorization: `Bearer ${chapaSecret}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: String(plan.amount), currency: "ETB", email: user.email,
        first_name: user.user_metadata?.full_name?.split(" ")[0] || "TEZAFLIX",
        last_name: user.user_metadata?.full_name?.split(" ").slice(1).join(" ") || "User",
        tx_ref,
        callback_url: `${supabaseUrl}/functions/v1/chapa-payment`,
        return_url: `${siteUrl}?payment=return&tx_ref=${encodeURIComponent(tx_ref)}`,
        customization: { title: "TEZAFLIX Premium", description: `${plan_id} subscription` },
      }),
    });
    const data = await response.json();
    if (!response.ok || data?.status === "failed" || !data?.data?.checkout_url) throw new Error(data?.message || "Chapa initialization failed");

    return new Response(JSON.stringify({ success: true, checkout_url: data.data.checkout_url, tx_ref, subscription_id: sub.id }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    return new Response(JSON.stringify({ success: false, message: error instanceof Error ? error.message : "Payment failed" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
